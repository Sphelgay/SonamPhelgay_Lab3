package io.test.fr;

import java.util.*;

public class FindPair {

	static class Node {
		int data;
		Node left, right;
	};

	static Node NewNode(int data)
	{
		Node temp = new Node();
		temp.data = data;
		temp.left = null;
		temp.right = null;
		return temp;
	}

	static Node insert(Node root, int key)
	{
		if (root == null)
			return NewNode(key);
		if (key < root.data)
			root.left = insert(root.left, key);
		else
			root.right = insert(root.right, key);
		return root;
	}

	static boolean findpairUtil(Node root, int sum,
								HashSet<Integer> list1)
	{
		if (root == null)
			return false;

		if (findpairUtil(root.left, sum, list1))
			return true;

		if (list1.contains(sum - root.data)) {
			System.out.println("Pair is found: ("
							+ (sum - root.data) + ", "
							+ root.data + ")");
			return true;
		}
		else
			list1.add(root.data);

		return findpairUtil(root.right, sum, list1);
	}

	static void findPair(Node root, int sum)
	{
		HashSet<Integer> set = new HashSet<Integer>();
		if (!findpairUtil(root, sum, set))
			System.out.print("Pairs do not exit"
							+ "\n");
	}

}

