package io.test.fr;

import java.util.Scanner;

public class BalancedBracketsDrive {

		// Driver code
		public static void main(String[] args)
		{
			//String expr = "([{}])";
			Scanner cx = new Scanner(System.in);
			System.out.print("Enter an expression for balanced testing: ");
			String expr = cx.nextLine();
			System.out.println(expr);
			cx.close();

			// Function call
			if (BalancedBrackets.areBracketsBalanced(expr))
				System.out.println("Balanced ");
			else
				System.out.println("Not Balanced ");
		}
	}



