package io.test.fr;

import java.util.*;

import io.test.fr.FindPair.Node;

public class FindPairDriver {
	
	public static void main(String[] args)
	{
		Node root = null;
		root = FindPair.insert(root, 15);
		root = FindPair.insert(root, 10);
		root = FindPair.insert(root, 20);
		root = FindPair.insert(root, 8);
		root = FindPair.insert(root, 12);
		root = FindPair.insert(root, 16);
		root = FindPair.insert(root, 25);
		root = FindPair.insert(root, 10);

		//int sum = 33;
		Scanner cx = new Scanner(System.in);
		System.out.print("Sum : ");
		int sum = cx.nextInt();
		System.out.println(sum);
		cx.close();
		
		FindPair.findPair(root, sum);
	}
	}


